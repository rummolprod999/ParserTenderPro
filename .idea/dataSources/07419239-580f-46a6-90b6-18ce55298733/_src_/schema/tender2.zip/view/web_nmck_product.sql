CREATE VIEW web_nmck_product AS
  SELECT
    `prod`.`id_od_contract`           AS `contract`,
    `prod`.`name`                     AS `product_name`,
    `prod`.`okpd2_code`               AS `okpd2`,
    `prod`.`okpd_code`                AS `okpd`,
    `prod`.`price`                    AS `price`,
    `prod`.`okpd_name`                AS `okpd_name`,
    `prod`.`quantity`                 AS `quantity`,
    `prod`.`okei`                     AS `okei`,
    `contract`.`region_code`          AS `region_code`,
    `contract`.`sign_date`            AS `sign_date`,
    `contract`.`fz`                   AS `fz`,
    `contract`.`execution_start_date` AS `contract_start`,
    `contract`.`execution_end_date`   AS `contract_end`,
    `contract`.`url`                  AS `oos_url`,
    `ten`.`id_placing_way`            AS `id_placing_way`,
    `p_w`.`conformity`                AS `pw_code`,
    `p_w`.`name`                      AS `p_w_name`,
    `ten`.`id_etp`                    AS `id_etp`,
    `eatp`.`name`                     AS `etp_name`,
    `ten`.`id_region`                 AS `id_region`,
    `regi_on`.`name`                  AS `region_name`,
    `contract`.`id_customer`          AS `id_customer`,
    `prod`.`sum`                      AS `summ`
  FROM (((((`tender2`.`od_contract_product` `prod` LEFT JOIN `tender2`.`od_contract` `contract`
      ON ((`contract`.`id` = `prod`.`id_od_contract`))) LEFT JOIN `tender2`.`tender` `ten`
      ON ((`ten`.`purchase_number` = `contract`.`notification_number`))) LEFT JOIN `tender2`.`placing_way` `p_w`
      ON ((`p_w`.`id_placing_way` = `ten`.`id_placing_way`))) LEFT JOIN `tender2`.`etp` `eatp`
      ON ((`eatp`.`id_etp` = `ten`.`id_etp`))) LEFT JOIN `tender2`.`region` `regi_on`
      ON ((`regi_on`.`id` = `ten`.`id_region`)))
  WHERE (`contract`.`cancel` = 0);
