CREATE VIEW web_org_supplier AS
  SELECT
    'Поставщик'                                AS `Роль_организации`,
    `tender2`.`od_supplier`.`organizationName` AS `Полное_наименование`,
    `tender2`.`od_supplier`.`inn`              AS `ИНН`,
    (SELECT `cont`.`regnum`
     FROM
       (`tender2`.`od_contract` `cont` LEFT JOIN `tender2`.`od_supplier` `sup` ON ((`cont`.`id_supplier` = `sup`.`id`)))
     WHERE (`sup`.`id` = `tender2`.`od_supplier`.`id`)
     ORDER BY `cont`.`sign_date` DESC
     LIMIT 1)                                  AS `Идентификатор`,
    (SELECT `cont`.`sign_date`
     FROM `tender2`.`od_contract` `cont`
     WHERE (`cont`.`regnum` = `Идентификатор`)
     ORDER BY `cont`.`sign_date` DESC
     LIMIT 1)                                  AS `Дата_последнего_действия`,
    `tender2`.`region`.`name`                  AS `Рeгион`,
    1                                          AS `Действующий`,
    'Заключение контракта'                     AS `Последнее_действие`,
    'Потом добавим'                            AS `Контактные_данные`,
    `tender2`.`region`.`id`                    AS `id_region`
  FROM (`tender2`.`od_supplier`
    LEFT JOIN `tender2`.`region` ON ((`tender2`.`region`.`conf` = `tender2`.`od_supplier`.`region_code`)))
  WHERE (`tender2`.`od_supplier`.`organizationName` <> '');
