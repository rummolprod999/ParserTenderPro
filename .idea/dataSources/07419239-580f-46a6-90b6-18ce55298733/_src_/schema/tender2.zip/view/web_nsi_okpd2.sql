CREATE VIEW web_nsi_okpd2 AS
  SELECT
    `tender2`.`okpd2_sprav`.`id`     AS `id`,
    `tender2`.`okpd2_sprav`.`code`   AS `code`,
    `tender2`.`okpd2_sprav`.`name`   AS `name`,
    `tender2`.`okpd2_sprav`.`level`  AS `level`,
    `tender2`.`okpd2_sprav`.`parent` AS `parent`
  FROM `tender2`.`okpd2_sprav`;
