CREATE VIEW web_nsi_etp AS
  SELECT
    `tender2`.`etp`.`id_etp` AS `id_etp`,
    `tender2`.`etp`.`code`   AS `code`,
    `tender2`.`etp`.`name`   AS `name`,
    `tender2`.`etp`.`url`    AS `url`,
    `tender2`.`etp`.`conf`   AS `conf`
  FROM `tender2`.`etp`;
