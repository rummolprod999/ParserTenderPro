CREATE VIEW web_nsi_regions AS
  SELECT
    `tender2`.`region`.`id`       AS `id`,
    `tender2`.`region`.`okrug_id` AS `okrug_id`,
    `tender2`.`region`.`name`     AS `name`,
    `tender2`.`region`.`path`     AS `path`,
    `tender2`.`region`.`conf`     AS `conf`,
    `tender2`.`region`.`path223`  AS `path223`
  FROM `tender2`.`region`;
